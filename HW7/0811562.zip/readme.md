please use following command to compile:
gcc -g -Wall -std=c99 0811562.c -o 0811562.exe
