using the following command to compile:
gcc -g -Wall 0811562.c -o 0811562.exe